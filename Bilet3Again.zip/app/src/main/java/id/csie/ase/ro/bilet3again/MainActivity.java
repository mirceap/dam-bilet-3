package id.csie.ase.ro.bilet3again;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private List<Autovehicul> listAutos = new ArrayList<>();
    private static int REQUEST_CODE_ADD = 1;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        Button btnAdd = findViewById(R.id.btnAdauga);
        Button btnList = findViewById(R.id.btnList);
        Button btnJson = findViewById(R.id.btnJson);
        Button btnSave = findViewById(R.id.btnSaveToDB);
        Button btnReport = findViewById(R.id.btnRaport);
        Button btnAbout = findViewById(R.id.btnDespre);

        btnAbout.setOnClickListener((v) -> {
            Toast.makeText(this, getString(R.string.creator) , Toast.LENGTH_SHORT).show();
        });

        btnAdd.setOnClickListener((v)->{
            Intent intent = new Intent(MainActivity.this, addAuto.class);
            startActivityForResult(intent, REQUEST_CODE_ADD);
        });

        btnList.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ListaAutoActivity.class);
            intent.putExtra(getString(R.string.send_to_list), (Serializable) listAutos);
            startActivity(intent);
        });
        btnSave.setOnClickListener(v -> {
            dbHelper.addList(listAutos);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == REQUEST_CODE_ADD && resultCode == RESULT_OK){
            listAutos.add((Autovehicul) data.getSerializableExtra(getString(R.string.add_auto_intent_name)));
        }
    }
}
